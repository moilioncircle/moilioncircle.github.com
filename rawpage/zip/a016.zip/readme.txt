用Firefox打开 index.html 即可浏览演示文稿。
若Chrome，file://无法实现XHR，需要自建http://