function showalert(title,content)
{
		$.layer({
		title: [
            title,
            'background:#F3F3F3; height:38px; color:#616161; border:none;' //自定义标题样式
        ],
		type : 0,
		shade : [0.5 , '#000' , true],
		shadeClose : true,
		border : [0],
		area: ['360px', '160px'],
		dialog: {
			type: -1,
			msg: content
		}
	})

}
function showmsg(info)
{
    var timer;
    art.dialog({
    lock:true,
    content: info,
    init: function () {
        var that = this, i = 3;
        var fn = function () {
            that.title(i + '秒后关闭');
            !i && that.close();
            i --;
        };
        timer = setInterval(fn, 1000);
        fn();
    },
    close: function () {
        clearInterval(timer);
    }
    }).show();
}

function closeui()
{
    $.unblockUI();
}
